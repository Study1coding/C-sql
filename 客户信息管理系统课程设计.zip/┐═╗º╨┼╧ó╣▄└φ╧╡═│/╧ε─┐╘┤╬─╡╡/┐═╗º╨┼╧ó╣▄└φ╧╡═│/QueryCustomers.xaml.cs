﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Data;
using System.Data.SqlClient;
using System.IO;
namespace 客户信息管理系统
{
    /// <summary>
    /// QueryCustomers.xaml 的交互逻辑
    /// </summary>
    /// 
    /// 
    /// 注意这个连接字符串最后想个办法妥善处理----方法一是准备个txt文件存该路径
    /// 
    /// 
    /// 
    /// 
    public partial class QueryCustomers : Window,IDesign
    {
        InformationDataSet InforDs;
        InformationDataSetTableAdapters.CustomerTableAdapter customerAdapter;
        InformationDataSetTableAdapters.PurchaseTableAdapter purchaseTableAdapter;
        bool ASC_bool;
        DataView view;
        bool leave = true;
        public QueryCustomers()
        {
            InitializeComponent();
            InforDs = new InformationDataSet();
            customerAdapter = new InformationDataSetTableAdapters.CustomerTableAdapter();
            purchaseTableAdapter = new InformationDataSetTableAdapters.PurchaseTableAdapter();
            view = new DataView();
            //customerAdapter.Fill(InforDs.Customer);
            //purchaseTableAdapter.Fill(InforDs.Purchase);
            //listView1.DataContext = InforDs.Tables["Customer"];
            //listView2.DataContext = InforDs.Tables["Customer"];
            //listView1.SelectedIndex = 0;
        }
        public void TextBox_MouseLeave(object sender, MouseEventArgs e)
        {
            if (sender is TextBox)
            {
                TextBox textBox = (TextBox)sender;
                textBox.IsReadOnly = true;
            }
            leave = true;
        }
        public void Edit(object sender, MouseButtonEventArgs e)
        {
            if (sender is TextBox)
            {
                TextBox textBox = (TextBox)sender;
                textBox.IsReadOnly = false;
            }
            leave = false;
        }
        public void Storage(object sender, RoutedEventArgs e)//做保存
        {
            if (InforDs.HasErrors)
            {
                MessageBox.Show("表中存在错误！");
                return;
            }

            if (InforDs.HasChanges())
            {
                customerAdapter.Update(InforDs.Customer);////这种update似乎是复合了很细致的方法，我连普通update都用的不是很好
                                                         //我大概是清楚了，是本质上和普通的sql的update并没区别，即便是表可视化为空，只要中间不是通过一行一行sql删除的，就不会影响表数据，关键是根据主键来更新。
                purchaseTableAdapter.Update(InforDs.Purchase);
                MessageBox.Show("修改已保存！", "保存修改");
                InforDs.AcceptChanges();
            }
        }
        public void Add(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (leave == true)
            {
                try
                {
                    DataRow dr = InforDs.Tables["Customer"].NewRow();
                    dr["CustomerID"] = 0;
                    dr["CustomerName"] = "";
                    dr["CustomerAge"] = "0";
                    dr["CustomerPassword"] = "123";
                    InforDs.Tables["Customer"].Rows.Add(dr);
                    label1.Content = "客户数：" + listView1.Items.Count.ToString();
                }
                catch (Exception)
                { }
            }
        }
        public void Delete(object sender, RoutedEventArgs e)
        {
            try
            {
                if (MessageBoxResult.Yes == MessageBox.Show("确定要删除吗？", "删除记录", MessageBoxButton.YesNo, MessageBoxImage.Exclamation))
                {
                    DataRowView drv = (DataRowView)listView1.SelectedItem;
                    drv.Delete();
                    label1.Content = "客户数：" + listView1.Items.Count.ToString();
                }
            }
            catch (Exception)
            { }
            //int id = listView1.Items.CurrentPosition;
            //ds.Tables["Student"].Rows[id].Delete();//从dataset删起来更直接
            //if (MessageBoxResult.Yes == MessageBox.Show("确定要删除吗？", "删除记录", MessageBoxButton.YesNo, MessageBoxImage.Exclamation))
            //{
            //    int id = listView1.Items.CurrentPosition;
            //    //InforDs.Tables["Customer"].Rows[id].Delete();
            //    InforDs.Tables["Customer"].Rows[0].Delete();

            //    label1.Content = "客户数：" + listView1.Items.Count.ToString();
            //        MessageBox.Show("id="+id.ToString());
            //}
        }
        public void DesignClose(object sender, RoutedEventArgs e)
        {
            if (InforDs.HasChanges())
            {
                if (MessageBoxResult.Yes == MessageBox.Show("有数据未保存，确定要关闭吗？", "关闭窗口", MessageBoxButton.YesNo, MessageBoxImage.Exclamation))
                {
                    Close();
                }
                return;
            }
            if (MessageBoxResult.Yes == MessageBox.Show("确定要关闭吗？", "关闭窗口", MessageBoxButton.YesNo, MessageBoxImage.Exclamation))
                Close();
        }
        public void InputGesture(object sender, KeyEventArgs e)
        {
            if ((Keyboard.GetKeyStates(Key.LeftCtrl) & KeyStates.Down) > 0)
            {
                if ((Keyboard.GetKeyStates(Key.S) & KeyStates.Down) > 0)
                    Storage(sender, e);
            }
            if ((Keyboard.GetKeyStates(Key.LeftCtrl) & KeyStates.Down) > 0)
            {
                if ((Keyboard.GetKeyStates(Key.W) & KeyStates.Down) > 0)
                    DesignClose(sender, e);
            }
            if ((Keyboard.GetKeyStates(Key.Enter) & KeyStates.Down) > 0)
                Search(sender, e);

            ////////////////////////////////////////////////////补充设置外键
            if ((Keyboard.GetKeyStates(Key.LeftCtrl) & KeyStates.Down) > 0)
            {
                if ((Keyboard.GetKeyStates(Key.Z) & KeyStates.Down) > 0)
                    InforDs.RejectChanges();//将表的可视化退回到上次保存的状态
            }
            ////////////////////////////////////////////////////
        }
        public void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            comboBox2.Items.Clear();
            ListBoxItem lbi = comboBox1.SelectedItem as ListBoxItem;
            string s = lbi.Content.ToString();
            if (s == "账号")
            {///请注意这个items属性是一个items集合类，这个集合会帮助一切itemscontrols控件类
                comboBox2.Items.Add(">");
                comboBox2.Items.Add(">=");
                comboBox2.Items.Add("=");
                comboBox2.Items.Add("<=");
                comboBox2.Items.Add("<");
                comboBox2.Items.Add("<>");
            }
            else if (s == "姓名")
            {
                comboBox2.Items.Add("=");
                comboBox2.Items.Add("like");///?
            }
            else
            {
                comboBox2.Items.Add("=");
            }
            comboBox2.SelectedIndex = 0;
        }
        public void Search(object sender, RoutedEventArgs e)
        {
            //InforDs.Relations["Customer_Purchase"].

            ////////////////////////////////////////////////////补充设置外键
            InforDs.EnforceConstraints = false;
            ////////////////////////////////////////////////////
            string filterstring;
            if (comboBox1.Text == "" || comboBox2.Text == "" || textBox1.Text == "")
            {
                customerAdapter.Fill(InforDs.Customer);
                purchaseTableAdapter.Fill(InforDs.Purchase);
                listView1.DataContext = InforDs.Tables["Customer"];
                listView2.DataContext = InforDs.Tables["Customer"];
                listView1.SelectedIndex = 0;
                return;
            }
            if (comboBox1.Text == "账号")
            {
                filterstring = "CustomerID" + comboBox2.Text + " " + textBox1.Text + " ";
            }
            else if (comboBox1.Text == "姓名")
            {
                if (comboBox2.Text == "=")
                {
                    filterstring = "CustomerName" + " " + comboBox2.Text + " " + "N'" + textBox1.Text + "'";
                }
                else
                {
                    filterstring = "CustomerName" + " " + comboBox2.Text + " " + "N'" + textBox1.Text + "'";//%是后通配符
                }
            }
            else//代表性别
            {
                //where customersex = N'男''女'
                filterstring = "CustomerSex " + comboBox2.Text + " N'" + textBox1.Text + "'";
            }
            ///开始连接数据库并做筛选
            ///
            string sc="";
            DBConn(out sc);
            SqlConnection conn = new SqlConnection(@sc);
            string s = "select * from Customer where " + " " + filterstring;
            SqlDataAdapter da = new SqlDataAdapter(s, conn);
            DataSet ds1 = new DataSet();
            try
            {
                da.Fill(ds1, "Customer");//该表中现在存储了筛选后的表
                                         ///////////////////////////////////////////////////////////////////////////////////////////
                                         ////每次删除掉上一次的表数据后重新赋值
                InformationDataSetTableAdapters.CustomerIDTableTableAdapter snta = new InformationDataSetTableAdapters.CustomerIDTableTableAdapter();
                snta.DeleteAll();
                snta.Fill(InforDs.CustomerIDTable);
                DataTable dt = ds1.Tables["Customer"];
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DataRow row = InforDs.Tables["CustomerIDTable"].NewRow();
                    row["CustomerId"] = dt.Rows[i]["CustomerID"];
                    InforDs.Tables["CustomerIDTable"].Rows.Add(row);
                }
                snta.Update(InforDs.CustomerIDTable);
                customerAdapter.FillINCustomerIDTable(InforDs.Customer);
                purchaseTableAdapter.FillINCustomerIDTable(InforDs.Purchase);
                listView1.DataContext = InforDs.Tables["Customer"];
                listView2.DataContext = InforDs.Tables["Customer"];
                listView1.SelectedIndex = 0;//调用seleciotnChange，实现主从显示的一致性
                //InforDs.RejectChanges();
                //////////////////////////////////////////////////补充设置外键
                InforDs.EnforceConstraints = true;
                ////////////////////////////////////////////////////
            }
            catch (Exception)
            { }
        }
        public void Order(object sender, RoutedEventArgs e)
        {
            view.Table = InforDs.Customer;
            GridViewColumnHeader gridViewColumnHeader = (GridViewColumnHeader)sender;
            string s = "";
            switch (gridViewColumnHeader.Content.ToString())
            {
                case "账号":
                    s = "CustomerID";
                    break;
                case "年龄":
                    s = "CustomerAge";
                    break;
                case "姓名":
                    s = "CustomerName";
                    break;
                case "性别":
                    s = "CustomerSex";
                    break;
                default: break;
            }
            if (ASC_bool == false)//即从没有执行过升序
            {
                view.Sort = s + " " + "ASC";
                ASC_bool = true;
            }
            else
            {
                view.Sort = s + " " + "DESC";
                ASC_bool = false;
            }
            listView1.ItemsSource = view;///左边看来是一个普遍的大集合，比viwe更具一般性
        }//做排序
        public void MenuItem_Click(object sender, RoutedEventArgs e)//汇总函数
        {
            MenuItem menuItem = (MenuItem)sender;
            //DataTable dt = InforDs.Customer.DefaultView.ToTable();//为了只对显示在listview里的数据进行汇总对这个窗口而言可以更简单
            //view.Table= InforDs.Customer.DefaultView;
            view.Table= InforDs.Customer;//使用table方法可以不使listview间接绑定到view，影响接下来的显示
            switch (menuItem.Header)
            {
                case "求总人数":
                    label1.Content = "总人数数 " + InforDs.Customer.Rows.Count.ToString();
                    break;
                case "求最大年龄":
                    label1.Content = "年龄最大值 " + InforDs.Customer.Compute(" Max(CustomerAge) ", "true").ToString();
                    break;
                case "求最小年龄":
                    label1.Content = "年龄最小值 " + InforDs.Customer.Compute(" Min(CustomerAge) ", "true").ToString();
                    break;
                case "求男性人数":
                    view.RowFilter = "CustomerSex = '男'";
                    label1.Content = "男性人数 " + view.Count.ToString();
                    break;
                case "求女性人数":
                    view.RowFilter = "CustomerSex = '女'";
                    label1.Content = "女性人数 " + view.Count.ToString();
                    break;
                case "求平均年龄":
                    //label1.Content = "平均年龄 " + InforDs.Customer.Compute(" Avg(CustomerAge)", "true").ToString();
                    double a = InforDs.Customer.Rows.Count;
                    double b = Convert.ToDouble(InforDs.Customer.Compute(" Sum(CustomerAge) ", "true"));
                    label1.Content = "平均年龄 " + Math.Round((b / a), 2).ToString();
                    break;
                default: break;
            }
        }
        private bool DBConn( out string SqlConnTxt)
        {
            SqlConnection conn;
            StreamReader sr = null;
            bool blnConnSuccess = true;
            SqlConnTxt = "";
            try
            {
                sr = File.OpenText(@".\sqlconn.txt");//从设置文件中读出数据库连接串

                while (sr.Peek() != -1)
                {
                    SqlConnTxt += sr.ReadLine();
                }
                if (SqlConnTxt == "")
                    throw new Exception("数据库（文件）连接字串定义异常！");
            }
            catch (DirectoryNotFoundException e1)
            {
                MessageBox.Show(e1.Message + "退出程序！", "出错！", MessageBoxButton.OK, MessageBoxImage.Error);
                blnConnSuccess = false;
            }
            catch (FileNotFoundException e1)
            {
                MessageBox.Show(e1.Message + "退出程序！", "出错！", MessageBoxButton.OK, MessageBoxImage.Error);
                blnConnSuccess = false;
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message + "退出程序！", "出错！", MessageBoxButton.OK, MessageBoxImage.Error);
                blnConnSuccess = false;
            }
            finally
            {
                if (sr != null)
                    sr.Close();
            }
            if (blnConnSuccess)
            {
                conn = new SqlConnection(SqlConnTxt);
                try
                {
                    conn.Open();
                    conn.Close();
                }
                catch (SqlException e)
                {
                    MessageBox.Show(e.Message, "连接出错", MessageBoxButton.OK, MessageBoxImage.Error);
                    blnConnSuccess = false;
                }
            }
            return blnConnSuccess;
        }//连接数据库测试，成功返回True
    }//Query CLASS END
    public interface IDesign
    {
        void InputGesture(object sender, KeyEventArgs e);//参数待补充
        void Add(object sender, System.Windows.Input.MouseButtonEventArgs e);//
        void Edit(object sender, MouseButtonEventArgs e);//
        void Delete(object sender, RoutedEventArgs e);//
        void TextBox_MouseLeave(object sender, MouseEventArgs e);
        void Order(object sender, RoutedEventArgs e);
        void Storage(object sender, RoutedEventArgs e);
        void DesignClose(object sender, RoutedEventArgs e);
        void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e);
        void Search(object sender, RoutedEventArgs e);
        void MenuItem_Click(object sender, RoutedEventArgs e);//汇总函数
    }//接口尾
}
