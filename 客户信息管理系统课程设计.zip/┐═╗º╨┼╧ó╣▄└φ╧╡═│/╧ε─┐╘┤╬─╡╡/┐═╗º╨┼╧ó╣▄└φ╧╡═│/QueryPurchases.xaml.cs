﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Input;
using System.Collections.ObjectModel;
namespace 客户信息管理系统
{
    /// <summary>
    /// QueryPurchases.xaml 的交互逻辑
    /// </summary>
    public partial class QueryPurchases : Window,IDesign
    {
        InformationDataSet InforDs;
        InformationDataSetTableAdapters.CustomerTableAdapter customerAdapter;
        InformationDataSetTableAdapters.PurchaseTableAdapter purchaseTableAdapter;
        InformationDataSetTableAdapters.GoodsTableAdapter goodsTableAdapter;
        bool ASC_bool;
        DataView view;
        bool leave = true;
        public QueryPurchases()
        {
            InitializeComponent();
            InforDs = new InformationDataSet();
            goodsTableAdapter = new InformationDataSetTableAdapters.GoodsTableAdapter();
            customerAdapter = new InformationDataSetTableAdapters.CustomerTableAdapter();
            purchaseTableAdapter = new InformationDataSetTableAdapters.PurchaseTableAdapter();
            view = new DataView();
            InforDs.EnforceConstraints = false;
            purchaseTableAdapter.Fill(InforDs.Purchase);
            listView1.ItemsSource = InforDs.Tables["Purchase"].DefaultView;
            view = InforDs.Purchase.DefaultView;
            listView1.SelectedIndex = 0;
            comboBox1.SelectedIndex = 0;
            //InforDs.Purchase.Columns["GoodsPrice"].Expression = "Convert(,'System.Double')";
            ////为什么加上true就不行，但最终必须加上才能保护数据完整性。
            ///InforDs.EnforceConstraints =true;
        }
        public void TextBox_MouseLeave(object sender, MouseEventArgs e)
        {
            if (sender is TextBox)
            {
                TextBox textBox = (TextBox)sender;
                textBox.IsReadOnly = true;
            }
            leave = true;
        }
        public void Edit(object sender, MouseButtonEventArgs e)
        {
            if (sender is TextBox)
            {
                TextBox textBox = (TextBox)sender;
                textBox.IsReadOnly = false;
            }
            leave = false;
        }
        public void Storage(object sender, RoutedEventArgs e)//做保存
        {
            if (InforDs.HasChanges())
            {
                goodsTableAdapter.Update(InforDs);
                purchaseTableAdapter.Update(InforDs);
                MessageBox.Show("修改已保存！", "保存修改");
            }
        }
        public void Add(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (leave == true)
            {
                try
                {
                    //view = (DataView)listView1.ItemsSource;
                    //DataRowView drv =view.AddNew();
                    DataRow dr = InforDs.Tables["Purchase"].NewRow();
                    dr["PurchaseID"] = 0;
                    dr["CustomerName"] = "";//应该是输入Name自动匹配ID
                    dr["PurchaseDate"]= System.DateTime.Today.Date.ToShortDateString();//默认用当前日期
                InforDs.Tables["Purchase"].Rows.Add(dr);
                    ////新加上去
                    view.RowFilter = string.Empty;
                    textBox1.Text = string.Empty;
                }
                catch (Exception)
                { }
            }
        }
        public void Delete(object sender, RoutedEventArgs e)
        {
            //InforDs.EnforceConstraints = true;
            if (MessageBoxResult.Yes == MessageBox.Show("确定要删除吗？", "删除记录", MessageBoxButton.YesNo, MessageBoxImage.Exclamation))
            {
                try
                {
                    DataRowView drv = (DataRowView)listView1.SelectedItem;
                    drv.Delete();
                }
                catch (Exception)
                {
                }
             
            }
        }
        public void Window_Loaded(object sender, RoutedEventArgs e)
        {
            label1.Content = "客户数：" + InforDs.Customer.Rows.Count.ToString();
        }
        public void DesignClose(object sender, RoutedEventArgs e)
        {
            if (InforDs.HasChanges())
            {
                if (MessageBoxResult.Yes == MessageBox.Show("有数据未保存，确定要关闭吗？", "关闭窗口", MessageBoxButton.YesNo, MessageBoxImage.Exclamation))
                {
                    Close();
                }
                return;
            }
            if (MessageBoxResult.Yes == MessageBox.Show("确定要关闭吗？", "关闭窗口", MessageBoxButton.YesNo, MessageBoxImage.Exclamation))
                Close();
        }
        public void InputGesture(object sender, KeyEventArgs e)
        {
            if ((Keyboard.GetKeyStates(Key.LeftCtrl) & KeyStates.Down) > 0)
            {
                if ((Keyboard.GetKeyStates(Key.S) & KeyStates.Down) > 0)
                    Storage(sender, e);
            }
            if ((Keyboard.GetKeyStates(Key.LeftCtrl) & KeyStates.Down) > 0)
            {
                if ((Keyboard.GetKeyStates(Key.W) & KeyStates.Down) > 0)
                    DesignClose(sender, e);
            }
            if ((Keyboard.GetKeyStates(Key.Enter) & KeyStates.Down) > 0)
                Search(sender, e);
        }
        public void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            comboBox2.Items.Clear();
            ListBoxItem lbi = comboBox1.SelectedItem as ListBoxItem;
            string s = lbi.Content.ToString();
            textBox1.Visibility = Visibility.Visible;
            if (s == "购物号" || s == "单价")
            {///请注意这个items属性是一个items集合类，这个集合会帮助一切itemscontrols控件类
                comboBox2.Items.Add(">");
                comboBox2.Items.Add(">=");
                comboBox2.Items.Add("=");
                comboBox2.Items.Add("<=");
                comboBox2.Items.Add("<");
                comboBox2.Items.Add("<>");
            }
            else if (s == "商品名" || s == "客户名")
            {
                comboBox2.Items.Add("=");
                comboBox2.Items.Add("like");
            }
            else  //指的是回复和问题
            {
                textBox1.Visibility = Visibility.Hidden;//做了隐藏以免用户误会
                comboBox2.Items.Add("有");//查一下
                comboBox2.Items.Add("无");
            }
            comboBox2.SelectedIndex = 0;
        }
        public void Search(object sender, RoutedEventArgs e)//不知道为什么还没法用
        {
            //////////////////////////////////////////////////////补充设置外键
            //InforDs.EnforceConstraints = false;
            //////////////////////////////////////////////////////
            InforDs.EnforceConstraints = false;
            view = InforDs.Purchase.DefaultView;
            string filterstring;
            if (textBox1.Visibility==Visibility.Visible&&(comboBox1.Text == "" || comboBox2.Text == "" || textBox1.Text == ""))
            {
                view.RowFilter = string.Empty;
                listView1.ItemsSource = view;
                listView1.SelectedIndex = 0;
                return;
            }
            if (comboBox1.Text == "购物号")
            {
                filterstring = "PurchaseID" + comboBox2.Text + " " + textBox1.Text + " ";
            }
            else if (comboBox1.Text == "单价")
            {
                filterstring = "GoodsPrice" + comboBox2.Text + " " + textBox1.Text + " ";
            }
            else if (comboBox1.Text == "客户名")
            {
                if (comboBox2.Text == "=")
                {
                    filterstring = "CustomerName" + comboBox2.Text + " '" + textBox1.Text + "'";
                }
                else
                {
                    filterstring = "CustomerName" + " " + comboBox2.Text + " " + "'" + textBox1.Text + "'";//%是后通配符
                }
            }
            else if (comboBox1.Text == "商品名")
            {
                if (comboBox2.Text == "=")
                {
                    filterstring = "GoodsName" + " " + comboBox2.Text + " " + "'" + textBox1.Text + "'";
                }
                else
                {
                    filterstring = "GoodsName" + " " + comboBox2.Text + " " + "'" + textBox1.Text + "'";//%是后通配符   ---这个N不太准确
                }
            }
            else if(comboBox1.Text == "问题")
            {
                if (comboBox2.Text=="有")
                {
                    filterstring = "Question" + " " +"is not " + " NULL";
                }
                else 
                {
                    filterstring = "Question" + " " + "is " + " NULL";
                }
                textBox1.Text = string.Empty;
            }
            else//回复
            {
                if (comboBox2.Text == "有")
                {
                    filterstring = "Reply" + " " + "is not " + " NULL";
                }
                else
                {
                    filterstring = "Reply" + " " + "is " + " NULL";
                }
                textBox1.Text = string.Empty;
            }
            try
            {
                view.RowFilter = filterstring;
            }
            catch (Exception)
            {
                MessageBox.Show("格式输入不正确，如日期必须输入完整（“2022/1/1”）");
                return;
            }
            listView1.DataContext = view;
            listView1.SelectedIndex = 0;
            //////////////////////////////////////////////////////补充设置外键
            //InforDs.EnforceConstraints = true;
            //////////////////////////////////////////////////////
        }
        public void Order(object sender, RoutedEventArgs e)
        {
            //view.Table = InforDs.Purchase;
            GridViewColumnHeader gridViewColumnHeader = (GridViewColumnHeader)sender;
            string s = "";
            switch (gridViewColumnHeader.Content.ToString())
            {
                case "购物号":
                    s = "PurchaseID";
                    break;
                case "商品名":
                    s = "GoodsName";
                    break;
                case "客户名":
                    s = "CustomerName";
                    break;
                case "单价":
                    s = "GoodsPrice";
                    break;
                case "问题":
                    s = "Question";
                    break;
                case "回复":
                    s = "Reply";
                    break;
                case "商品号":
                    s = "GoodsNum";
                    break;
                case "客户号":
                    s = "CustomerID";
                    break;
                default: break;
            }
            if (ASC_bool == false)//即从没有执行过升序
            {
                view.Sort = s + " " + "ASC";
                ASC_bool = true;
            }
            else
            {
                view.Sort = s + " " + "DESC";
                ASC_bool = false;
            }
            listView1.ItemsSource = view;///左边看来是一个普遍的大集合，比viwe更具一般性
        }
        public void MenuItem_Click(object sender, RoutedEventArgs e)//汇总函数
        {
            MenuItem menuItem = (MenuItem)sender;
            DataTable dt = InforDs.Purchase.DefaultView.ToTable();//为了只对显示在listview里的数据进行汇总
            switch (menuItem.Header)
            {
                case "求记录数":
                    label1.Content = "记录数 " + dt.Rows.Count.ToString();
                    break;
                case "求最大":
                    label1.Content = "单价最大值 " + dt.Compute(" Max(GoodsPrice) ", "true").ToString();
                    break;
                case "求最小":
                    label1.Content = "单价最小值 " + dt.Compute(" Min(GoodsPrice) ", "true").ToString();
                    break;
                case "求和":
                    label1.Content = "价格求和 " + dt.Compute(" Sum(GoodsPrice) ", "true").ToString();
                    break;
                case "求平均":
                    //label1.Content = "平均价格 " + Math.Round(Convert.ToDouble(dt.Compute("Avg(GoodsPrice)", "true")),2).ToString();
                    double a = dt.Rows.Count;
                    double b = Convert.ToDouble(dt.Compute(" Sum(GoodsPrice) ", "true"));
                    label1.Content = "平均价格 " + Math.Round((b / a), 2).ToString();
                    break;
                default: break;
            }




        }
    }
}
