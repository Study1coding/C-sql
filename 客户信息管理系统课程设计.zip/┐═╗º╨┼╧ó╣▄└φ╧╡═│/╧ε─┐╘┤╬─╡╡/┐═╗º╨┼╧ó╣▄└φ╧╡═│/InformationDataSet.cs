﻿namespace 客户信息管理系统
{


    partial class InformationDataSet
    {
        partial class PurchaseDataTable
        {
        }
    }
}

namespace 客户信息管理系统.InformationDataSetTableAdapters {
    
    
    public partial class PurchaseTableAdapter {
    }
}
