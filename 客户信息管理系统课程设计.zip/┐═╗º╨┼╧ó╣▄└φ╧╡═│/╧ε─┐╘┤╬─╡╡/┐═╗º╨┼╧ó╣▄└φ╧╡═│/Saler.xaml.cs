﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
namespace 客户信息管理系统
{
    /// <summary>
    /// Saler.xaml 的交互逻辑
    /// </summary>
    public partial class Saler : Window
    {
        public string radioButtonState
        {
            get
            {
                string s = null;
                if (radioButton1.IsChecked == true)
                    s = radioButton1.Content.ToString();
                else if (radioButton2.IsChecked == true)
                    s = radioButton2.Content.ToString();
                else if (radioButton3.IsChecked == true)
                    s = radioButton3.Content.ToString();
                else if (radioButton4.IsChecked == true)
                    s = radioButton4.Content.ToString();
                return s;
            }
        }
        public Saler(string s)
        {
            InitializeComponent();
            if (s=="管理员")
            {
                radioButton4.Visibility = Visibility.Visible;
                radioButton4.IsChecked = true;
            }
            else
            {
                radioButton4.Visibility = Visibility.Hidden;
                radioButton1.IsChecked = true;
            }
            
        }
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            if (radioButtonState!=null)
            {
                switch (radioButtonState)
                {
                    case "客户信息":
                        QueryCustomers queryCustomers = new QueryCustomers();
                        queryCustomers.Show();//非模式方式打开
                        break;
                    case "商品信息":
                        QueryGoods queryGoods = new QueryGoods();
                        queryGoods.Show();
                        break;
                    case "消费记录":
                        QueryPurchases queryPurchases = new QueryPurchases();
                        queryPurchases.Show();
                        break;
                    case "销售员管理":
                        ManageSaler manageSaler = new ManageSaler();
                        manageSaler.Show();
                        break;
                }
            }
            else
            {
                MessageBox.Show("请选择功能！");
            }
        }
        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
        private void Window_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if ((Keyboard.GetKeyStates(Key.Enter) & KeyStates.Down) > 0)
            {
                button1_Click(sender, e);
            }
            if ((Keyboard.GetKeyStates(Key.LeftCtrl) & KeyStates.Down) > 0)
            {
                if ((Keyboard.GetKeyStates(Key.W) & KeyStates.Down) > 0)
                    button2_Click(sender, e);
            }
            if ((Keyboard.GetKeyStates(Key.LeftCtrl) & KeyStates.Down) > 0)
            {
                if ((Keyboard.GetKeyStates(Key.Z) & KeyStates.Down) > 0)
                    button0_Click(sender, e);
            }
        }

        private void button0_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
