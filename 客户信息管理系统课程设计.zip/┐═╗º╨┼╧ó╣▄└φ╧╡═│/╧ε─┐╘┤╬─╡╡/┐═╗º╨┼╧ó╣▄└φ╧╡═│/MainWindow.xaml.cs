﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.IO;
using System.Data;
/// <summary>
/// 上交的最后版本必须把数据库路径绑定到简单到D盘根目录下！！
/// 开发阶段暂时封在项目内部
/// </summary>
namespace 客户信息管理系统
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    /// 
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public string RadioButtonState
        {   
            get
            {
                string s = null;
                if (radioButton1.IsChecked == true)
                    s = radioButton1.Content.ToString();
                else if (radioButton2.IsChecked == true)
                    s = radioButton2.Content.ToString();
                else if (radioButton3.IsChecked == true)
                    s = radioButton3.Content.ToString();
                return s;
            }
        }
        private void Window_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if ((Keyboard.GetKeyStates(Key.Enter) & KeyStates.Down) > 0)
            {
                button1_Click(sender, e);
            }
        }
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            string s = RadioButtonState;
            DataTable table, purchaseTable;
            switch (s)
            {
                case "客户":
                    InformationDataSetTableAdapters.CustomerTableAdapter sTa =
                        new InformationDataSetTableAdapters.CustomerTableAdapter();
                    int n = int.Parse(textBox1.Text);
                    table = sTa.GetDataByCustomerID(n);
                    if (table.Rows.Count != 0)
                    {
                        if (table.Rows[0]["CustomerPassword"].ToString().Trim() == passwordBox1.Password)
                        {
                            progressbartest pb = new progressbartest();
                            pb.ShowDialog();
                            InformationDataSetTableAdapters.PurchaseTableAdapter scoreTa =
                                new InformationDataSetTableAdapters.PurchaseTableAdapter();
                            purchaseTable = scoreTa.GetDataByCustomerID((int)table.Rows[0]["CustomerID"]);
                            Customer cus = new Customer(table, purchaseTable);
                            cus.Show();
                            Close();
                        }
                        else MessageBox.Show("密码错误", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                    else
                        MessageBox.Show("查无此人");
                    break;
                case "销售员":
                    InformationDataSetTableAdapters.SalerTableAdapter SalerTableAdapter1 = new InformationDataSetTableAdapters.SalerTableAdapter();
                    int m1 = int.Parse(textBox1.Text);
                    table = SalerTableAdapter1.GetDataBySalerNum(m1);
                    if (table.Rows.Count != 0)
                    {
                        if (table.Rows[0]["SalerPassword"].ToString() == passwordBox1.Password)
                        {
                            progressbartest pb = new progressbartest();
                            pb.ShowDialog();
                            Saler md = new Saler(RadioButtonState);
                            md.Show();
                            Close();//关闭的是这个登录页面
                        }
                        else
                            MessageBox.Show("密码错误");
                    }
                    else
                        MessageBox.Show("查无此人");
                    /***************************************************/
                    break;
                case "管理员":
                    SalerTableAdapter1 = new InformationDataSetTableAdapters.SalerTableAdapter();
                    m1 = int.Parse(textBox1.Text);
                    table = SalerTableAdapter1.GetDataBySalerNum(m1);
                    if (table.Rows.Count != 0)//简单假定工号为2的销售员是管理员
                    {
                        if(m1==2)
                        {
                            if (table.Rows[0]["SalerPassword"].ToString() == passwordBox1.Password)
                            {
                                progressbartest pb = new progressbartest();
                                pb.ShowDialog();
                                ///用一个选择界面即可
                                Saler md = new Saler(RadioButtonState);
                                md.Show();
                                Close();
                            }
                            else
                                MessageBox.Show("密码错误");
                        }
                    }
                    else
                        MessageBox.Show("查无此人");
                    break;

            }
        }//button1
        private void button3_Click(object sender, RoutedEventArgs e)
        {
            Close();

        }
        public void InputGesture(object sender, KeyEventArgs e)
        {//登录和关闭
            if ((Keyboard.GetKeyStates(Key.Enter) & KeyStates.Down) > 0)
            {
                    button1_Click(sender, e);
            }
            if ((Keyboard.GetKeyStates(Key.LeftCtrl) & KeyStates.Down) > 0)
            {
                if ((Keyboard.GetKeyStates(Key.W) & KeyStates.Down) > 0)
                    button3_Click(sender, e);
            }
        }
        //这个用作querycustoemr窗口
        //private bool DBConn()
        //{
        //    StreamReader sr = null;
        //    bool blnConnSuccess = true;
        //    try
        //    {
        //        sr = File.OpenText(@".\sqlconn.txt");//从设置文件中读出数据库连接串

        //        while (sr.Peek() != -1)
        //        {
        //            SqlConnTxt += sr.ReadLine();
        //        }
        //        if (SqlConnTxt == "")
        //            throw new Exception("数据库（文件）连接字串定义异常！");
        //    }
        //    catch (DirectoryNotFoundException e1)
        //    {
        //        MessageBox.Show(e1.Message + "退出程序！", "出错！", MessageBoxButton.OK, MessageBoxImage.Error);
        //        blnConnSuccess = false;
        //    }
        //    catch (FileNotFoundException e1)
        //    {
        //        MessageBox.Show(e1.Message + "退出程序！", "出错！", MessageBoxButton.OK, MessageBoxImage.Error);
        //        blnConnSuccess = false;
        //    }
        //    catch (Exception e1)
        //    {
        //        MessageBox.Show(e1.Message + "退出程序！", "出错！", MessageBoxButton.OK, MessageBoxImage.Error);
        //        blnConnSuccess = false;
        //    }
        //    finally
        //    {
        //        if (sr != null)
        //            sr.Close();
        //    }
        //    if (blnConnSuccess)
        //    {
        //        conn = new SqlConnection(SqlConnTxt);
        //        try
        //        {
        //            conn.Open();
        //            conn.Close();
        //        }
        //        catch (SqlException e)
        //        {
        //            MessageBox.Show(e.Message, "连接出错", MessageBoxButton.OK, MessageBoxImage.Error);
        //            blnConnSuccess = false;
        //        }
        //    }
        //    return blnConnSuccess;
        //}//连接数据库测试，成功返回True
        //private void Window_Loaded(object sender, RoutedEventArgs e)
        //{
        //    if (!DBConn())
        //    {
        //        MessageBox.Show("连接数据库失败,程序中止，请与开发者联系！", "出错", MessageBoxButton.OK, MessageBoxImage.Error);
        //        Application.Current.Shutdown();
        //        this.Close();
        //    }
        //}
    }
}
