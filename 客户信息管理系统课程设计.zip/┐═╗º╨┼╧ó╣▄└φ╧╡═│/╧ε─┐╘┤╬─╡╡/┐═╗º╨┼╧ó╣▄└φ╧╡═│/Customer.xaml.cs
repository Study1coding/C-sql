﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.IO;
using System.Data;
namespace 客户信息管理系统
{
    /// <summary>
    /// Customer.xaml 的交互逻辑
    /// </summary>
    public partial class Customer : Window
    {
        DataTable table1, table2;
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if ((Keyboard.GetKeyStates(Key.LeftCtrl) & KeyStates.Down) > 0)
            {
                if ((Keyboard.GetKeyStates(Key.W) & KeyStates.Down) > 0)
                    Close();
            }
        }
        public Customer(DataTable t1,DataTable t2)
        {
            InitializeComponent();
            table1 = t1;
            table2 = t2;
            textBlock1.DataContext = table1;
            textBlock2.DataContext = table1;
            textBlock3.DataContext = table1;
            listView1.ItemsSource = table2.DefaultView;
        }
    }
}
