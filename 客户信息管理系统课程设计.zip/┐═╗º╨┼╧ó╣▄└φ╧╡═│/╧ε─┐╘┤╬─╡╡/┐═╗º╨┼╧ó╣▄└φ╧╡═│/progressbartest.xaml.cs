﻿using System.Windows;
using System.Threading;
namespace 客户信息管理系统
{
    /// <summary>
    /// progressbartest.xaml 的交互逻辑
    /// </summary>
    public partial class progressbartest : Window
    {
        int i;
        public progressbartest()
        {
            InitializeComponent();
            ProgressBegin();
        }
        private void ProgressBegin()
        {

            Thread thread = new Thread(new ThreadStart(() =>
            {
                for (i = 0; i <= 100; i++)
                {
                    this.progressBar1.Dispatcher.BeginInvoke((ThreadStart)delegate { this.progressBar1.Value = i; });
                    Thread.Sleep(20);
                }
            }));
            thread.Start();
        }
        private void progressBar1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (progressBar1.Value >= progressBar1.Maximum)
            {
                Close();
            }
            string s = "";
            if (i % 5 == 0)
            {
                for (int j = 0; j < i % 4; j++)
                {
                    s += ".";
                }
                this.Title = "正在加载" + s;
            }
        }
    }
}
