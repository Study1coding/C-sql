﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Data;
using System.Collections.ObjectModel;
namespace 客户信息管理系统
{
    /// <summary>
    /// ManageSaler.xaml 的交互逻辑
    /// </summary>
    public partial class ManageSaler : Window
    {
        InformationDataSet InforDs;
        InformationDataSetTableAdapters.CustomerTableAdapter customerAdapter;
        InformationDataSetTableAdapters.PurchaseTableAdapter purchaseTableAdapter;
        InformationDataSetTableAdapters.SalerTableAdapter salerTableAdapter;
        bool ASC_bool;
        DataView view;
        bool leave = true;
        public ManageSaler()
        {
            InitializeComponent();
            salerTableAdapter = new InformationDataSetTableAdapters.SalerTableAdapter();
            InforDs = new InformationDataSet();
            view = new DataView();
            //goodsTableAdapter = new InformationDataSetTableAdapters.GoodsTableAdapter();//不知道啥用
            customerAdapter = new InformationDataSetTableAdapters.CustomerTableAdapter();
            purchaseTableAdapter = new InformationDataSetTableAdapters.PurchaseTableAdapter();
            InforDs.EnforceConstraints = false;
            salerTableAdapter.Fill(InforDs.Saler);
            purchaseTableAdapter.Fill(InforDs.Purchase);
            listView1.ItemsSource = InforDs.Tables["Saler"].DefaultView;
            view = InforDs.Saler.DefaultView;
            listView1.SelectedIndex = 0;
            comboBox1.SelectedIndex = 0;
        }
        public void TextBox_MouseLeave(object sender, MouseEventArgs e)
        {
            if (sender is TextBox)
            {
                TextBox textBox = (TextBox)sender;
                textBox.IsReadOnly = true;
            }
            leave = true;
        }
        public void Edit(object sender, MouseButtonEventArgs e)
        {
            if (sender is TextBox)
            {
                TextBox textBox = (TextBox)sender;
                textBox.IsReadOnly = false;
            }
            leave = false;
        }
        public void Storage(object sender, RoutedEventArgs e)//做保存
        {
            if (InforDs.HasChanges())
            {
                salerTableAdapter.Update(InforDs);
                purchaseTableAdapter.Update(InforDs);
                MessageBox.Show("修改已保存！", "保存修改");
            }
        }
        public void Add(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {   
            if (leave == true)
            {
                try
                {
                    DataRow dr = InforDs.Tables["Saler"].NewRow();
                    dr["SalerNum"] = 0;
                    dr["SalerName"] = "";//应该是输入Name自动匹配ID
                    dr["SalerSex"] = "";
                    //dr["GoodsPrice"] = "0";//应该是输入商品自动匹配价格
                    //dr["Question"] = "";
                    //dr["S"] = "24";
                    //dr["PurchaseDate"] = System.DateTime.Today.Date.ToShortDateString();//默认用当前日期
                    InforDs.Tables["Saler"].Rows.Add(dr);
                    view.RowFilter = string.Empty;
                    textBox1.Text = string.Empty;
                }
                catch (Exception)
                { }
            }
        }
        public void Delete(object sender, RoutedEventArgs e)
        {
            if (MessageBoxResult.Yes == MessageBox.Show("确定要删除吗？", "删除记录", MessageBoxButton.YesNo, MessageBoxImage.Exclamation))
            {
                try
                {
                    DataRowView drv = (DataRowView)listView1.SelectedItem;
                    drv.Delete();
                }
                catch (Exception)
                {
                }
            }
        }
        public void DesignClose(object sender, RoutedEventArgs e)
        {
            if (InforDs.HasChanges())
            {
                if (MessageBoxResult.Yes == MessageBox.Show("有数据未保存，确定要关闭吗？", "关闭窗口", MessageBoxButton.YesNo, MessageBoxImage.Exclamation))
                {
                    Close();
                }
                return;
            }
            if (MessageBoxResult.Yes == MessageBox.Show("确定要关闭吗？", "关闭窗口", MessageBoxButton.YesNo, MessageBoxImage.Exclamation))
                Close();
        }
        public void InputGesture(object sender, KeyEventArgs e)
        {
            if ((Keyboard.GetKeyStates(Key.LeftCtrl) & KeyStates.Down) > 0)
            {
                if ((Keyboard.GetKeyStates(Key.S) & KeyStates.Down) > 0)
                    Storage(sender, e);
            }
            if ((Keyboard.GetKeyStates(Key.LeftCtrl) & KeyStates.Down) > 0)
            {
                if ((Keyboard.GetKeyStates(Key.W) & KeyStates.Down) > 0)
                    DesignClose(sender, e);
            }
            if ((Keyboard.GetKeyStates(Key.Enter)&KeyStates.Down) > 0)
            {
                Search(sender, e);
            }
        }
        public void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            comboBox2.Items.Clear();
            ListBoxItem lbi = comboBox1.SelectedItem as ListBoxItem;
            string s = lbi.Content.ToString();
            textBox1.Visibility = Visibility.Visible;
            if (s == "工号")
            {///请注意这个items属性是一个items集合类，这个集合会帮助一切itemscontrols控件类
                comboBox2.Items.Add(">");
                comboBox2.Items.Add(">=");
                comboBox2.Items.Add("=");
                comboBox2.Items.Add("<=");
                comboBox2.Items.Add("<");
                comboBox2.Items.Add("<>");
            }
            else if ( s == "姓名")
            {
                comboBox2.Items.Add("=");
                comboBox2.Items.Add("like");
            }
            else if (s == "性别")
            {
                comboBox2.Items.Add("=");
            }
            else  
            {
                ////textBox1.Visibility = Visibility.Hidden;
                ////comboBox2.Items.Add("is");
                ////comboBox2.Items.Add("is not");
            }
            comboBox2.SelectedIndex = 0;
        }
        public void Search(object sender, RoutedEventArgs e)
        {
            ////2.19临时加上
            InforDs.EnforceConstraints = false;

            view = InforDs.Saler.DefaultView;
            string filterstring;
            if (comboBox1.Text == "" || comboBox2.Text == "" || textBox1.Text == "")
            {
                view.RowFilter = string.Empty;
                textBox1.Text = string.Empty;
                //listView1.ItemsSource = view;
                ///以下代码存在隐患
                //purchaseTableAdapter.Fill(InforDs.Purchase);
                //listView1.DataContext = InforDs.Tables["Goods"];
                //listView1.SelectedIndex = 0;
                return;
            }
            if (comboBox1.Text == "工号")
            {
                filterstring = "SalerNum" + comboBox2.Text + " " + textBox1.Text + " ";
            }
            else if (comboBox1.Text == "姓名")
            {
                if (comboBox2.Text == "=")
                {
                    filterstring = "SalerName" + comboBox2.Text + " '" + textBox1.Text + "'";
                }
                else
                {
                    filterstring = "SalerName" + " " + comboBox2.Text + " " + "'" + textBox1.Text + "'";//%是后通配符
                }
            }
            //else if (comboBox1.Text == "商品名")
            //{
            //    if (comboBox2.Text == "=")
            //    {
            //        filterstring = "GoodsName" + " " + comboBox2.Text + " " + "'" + textBox1.Text + "'";
            //    }
            //    else
            //    {
            //        filterstring = "GoodsName" + " [" + comboBox2.Text + "] " + "N'" + textBox1.Text + "'";//%是后通配符   ---这个N不太准确
            //    }
            //}
            //else if (comboBox1.Text == "问题")
            //{
            //    filterstring = "Question" + " " + comboBox2.Text + " NULL";
            //}
            else//性别
            {
                filterstring = "SalerSex" + " " + comboBox2.Text + "'"+textBox1.Text+"'";
            }
            try
            {
                view.RowFilter = filterstring;
            }
            catch (Exception)
            {
                MessageBox.Show("格式输入不正确，如日期必须输入完整（“2022/1/1”）");
                return;
            }
            //listView1.ItemsSource= view;
            listView1.SelectedIndex = 0;
        }
        public void Order(object sender, RoutedEventArgs e)
        {
            //view.Table = InforDs.Goods;
            GridViewColumnHeader gridViewColumnHeader = (GridViewColumnHeader)sender;
            string s = "";
            switch (gridViewColumnHeader.Content.ToString())
            {
                case "工号":
                    s = "SalerNum";
                    break;
                case "姓名":
                    s = "SalerName";
                    break;
                case "性别":
                    s = "SalerSex";
                    break;
                //case "生产日期":
                //    s = "ProduceDate";
                //    break;
                //case "保质期/月":
                //    s = "StoreMonth";
                //    break;
                default: break;
            }
            if (ASC_bool == false)//即从没有执行过升序
            {
                view.Sort = s + " " + "ASC";
                ASC_bool = true;
            }
            else
            {
                view.Sort = s + " " + "DESC";
                ASC_bool = false;
            }
            listView1.ItemsSource = view;///左边看来是一个普遍的大集合，比viwe更具一般性
        }
        public void Statics(object sender, MouseButtonEventArgs e)
        {

        }
        public void MenuItem_Click(object sender, RoutedEventArgs e)//汇总函数
        {
            MenuItem menuItem = (MenuItem)sender;
            //DataTable dt = InforDs.Customer.DefaultView.ToTable();//为了只对显示在listview里的数据进行汇总对这个窗口而言可以更简单
            //view.Table= InforDs.Customer.DefaultView;
            DataTable dt = view.ToTable();
            switch (menuItem.Header)
            {
                case "求总人数":
                    label1.Content = "总人数数 " +dt.Rows.Count.ToString();
                    break;
                case "求男性人数":
                    view.RowFilter = "SalerSex = '男'";
                    label1.Content = "男性人数 " + view.Count.ToString();
                    break;
                case "求女性人数":
                    view.RowFilter = "SalerSex = '女'";
                    label1.Content = "女性人数 " + view.Count.ToString();
                    break;
                default: break;
            }
        }
    }
    public class SalerData: ObservableCollection<string>
    {
        public SalerData()
        {
            InformationDataSetTableAdapters.SalerTableAdapter salerTableAdapter = new InformationDataSetTableAdapters.SalerTableAdapter();
            InformationDataSet informationDataSet = new InformationDataSet();
            salerTableAdapter.Fill(informationDataSet.Saler);
            DataView dataView = new DataView(informationDataSet.Saler);
            DataTable table = dataView.ToTable(true, "SalerName");//现在是为了好添加，但是这样得把原来的添加修改的设计得推翻。设计一个新的添加窗口这样固然是很方便。
            for (int i = 0; i < table.Rows.Count; i++)
            {
                Add(table.Rows[i]["SalerName"].ToString());
            }
        }
    }
    //public class MyData2 : ObservableCollection<string>
    //{
    //    public MyData2()
    //    {
    //        InformationDataSetTableAdapters.GoodsTableAdapter goodsTableAdapter = new InformationDataSetTableAdapters.GoodsTableAdapter();
    //        InformationDataSet informationDataSet = new InformationDataSet();
    //        goodsTableAdapter.Fill(informationDataSet.Goods);
    //        DataView dataView = new DataView(informationDataSet.Goods);
    //        DataTable table = dataView.ToTable(true, "GoodsName");//现在是为了好添加，但是这样得把原来的添加修改的设计得推翻。设计一个新的添加窗口这样固然是很方便。
    //        for (int i = 0; i < table.Rows.Count; i++)
    //        {
    //            Add(table.Rows[i]["GoodsName"].ToString());
    //        }
    //    }
    //}
}
