﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Data;
using System.Data.SqlClient;
using System.Collections.ObjectModel;
namespace 客户信息管理系统
{
    /// <summary>
    /// QueryGoods.xaml 的交互逻辑
    /// </summary>
    public partial class QueryGoods : Window,IDesign
    {
        InformationDataSet InforDs;
        InformationDataSetTableAdapters.GoodsTableAdapter goodsTableAdapter;
        InformationDataSetTableAdapters.PurchaseTableAdapter purchaseTableAdapter;
        bool ASC_bool;
        DataView view;
        bool leave = true;
        public QueryGoods()
        {
            InitializeComponent();
            InforDs = new InformationDataSet();
            goodsTableAdapter = new InformationDataSetTableAdapters.GoodsTableAdapter();
            purchaseTableAdapter = new InformationDataSetTableAdapters.PurchaseTableAdapter();
            view = new DataView();
            /////////////////////////////////////////临时加上
            InforDs.EnforceConstraints = false;
            goodsTableAdapter.Fill(InforDs.Goods);
            purchaseTableAdapter.Fill(InforDs.Purchase);
            listView1.DataContext = InforDs.Tables["Goods"];
            view = InforDs.Goods.DefaultView;
            listView2.DataContext = InforDs.Tables["Goods"];
            listView1.SelectedIndex = 0;
            comboBox1.SelectedIndex = 0;//默认选第一个
            //InforDs.EnforceConstraints = true;
        }
        public void TextBox_MouseLeave(object sender, MouseEventArgs e)
        {
            if (sender is TextBox)
            {
                TextBox textBox = (TextBox)sender;
                textBox.IsReadOnly = true;
            }
            leave = true;
        }
        public void Edit(object sender, MouseButtonEventArgs e)
        {
            if (sender is TextBox)
            {
                TextBox textBox = (TextBox)sender;
                textBox.IsReadOnly = false;
            }
            leave = false;
        }
        public void Storage(object sender, RoutedEventArgs e)//做保存
        {
            if (InforDs.HasChanges())
            {
                goodsTableAdapter.Update(InforDs);
                purchaseTableAdapter.Update(InforDs);
                MessageBox.Show("修改已保存！", "保存修改");
            }
        }
        public void Add(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (leave == true)
            {
                try
                {
                    DataRow dr = InforDs.Tables["Goods"].NewRow();
                    dr["GoodsNum"] =0;
                    dr["GoodsName"] = "";
                    dr["GoodsPrice"] = 0;
                    ////////////自动设置成当前年月日
                    dr["ProduceDate"] = System.DateTime.Today.Date.ToShortDateString();//默认用当前日期
                    dr["StoreMonth"] =24;
                    InforDs.Tables["Goods"].Rows.Add(dr);
                }
                catch (Exception)
                {}
                ////新加上去
                view.RowFilter = string.Empty;
                textBox1.Text = string.Empty;
            }
        }
        public void Delete(object sender, RoutedEventArgs e)
        {
            if (MessageBoxResult.Yes == MessageBox.Show("确定要删除吗？", "删除记录", MessageBoxButton.YesNo, MessageBoxImage.Exclamation))
            {
                try
                {
                    DataRowView drv = (DataRowView)listView1.SelectedItem;
                    drv.Delete();
                    //label1.Content = "商品种类：" + listView1.Items.Count.ToString();
                }
                catch (Exception)
                {
                }
            }
        }
        public void Window_Loaded(object sender, RoutedEventArgs e)
        {
            label1.Content = "客户数：" + InforDs.Customer.Rows.Count.ToString();
        }
        public void DesignClose(object sender, RoutedEventArgs e)
        {
            if (InforDs.HasChanges())
            {
                if (MessageBoxResult.Yes == MessageBox.Show("有数据未保存，确定要关闭吗？", "关闭窗口", MessageBoxButton.YesNo, MessageBoxImage.Exclamation))
                {
                    Close();
                }
                return;
            }
            if (MessageBoxResult.Yes == MessageBox.Show("确定要关闭吗？", "关闭窗口", MessageBoxButton.YesNo, MessageBoxImage.Exclamation))
                Close();
        }
        public void InputGesture(object sender, KeyEventArgs e)
        {
            if ((Keyboard.GetKeyStates(Key.LeftCtrl) & KeyStates.Down) > 0)
            {
                if ((Keyboard.GetKeyStates(Key.S) & KeyStates.Down) > 0)
                    Storage(sender, e);
            }
            if ((Keyboard.GetKeyStates(Key.LeftCtrl) & KeyStates.Down) > 0)
            {
                if ((Keyboard.GetKeyStates(Key.W) & KeyStates.Down) > 0)
                    DesignClose(sender, e);
            }
            if ((Keyboard.GetKeyStates(Key.Enter) & KeyStates.Down) > 0)
                Search(sender, e);
        }
        public void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            comboBox2.Items.Clear();
            ListBoxItem lbi = comboBox1.SelectedItem as ListBoxItem;
            string s = lbi.Content.ToString();
            if (s == "商品号" || s == "价格￥" || s == "保质期/月" || s == "生产日期")
            {///请注意这个items属性是一个items集合类，这个集合会帮助一切itemscontrols控件类
                comboBox2.Items.Add(">");
                comboBox2.Items.Add(">=");
                comboBox2.Items.Add("=");
                comboBox2.Items.Add("<=");
                comboBox2.Items.Add("<");
                comboBox2.Items.Add("<>");
            }
            else if (s == "商品名")
            {
                comboBox2.Items.Add("=");
                comboBox2.Items.Add("like");
            }
            else 
            {
                comboBox2.Items.Add("=");
            }
            comboBox2.SelectedIndex = 0;
        }
        public void Search(object sender, RoutedEventArgs e)
        {////////////////////////////////////////////////////补充设置外键
            InforDs.EnforceConstraints = false;
            ////////////////////////////////////////////////////
            view= InforDs.Goods.DefaultView;
            string filterstring;
            if (comboBox1.Text == "" || comboBox2.Text == "" || textBox1.Text == "")
            {
                /// 以下代码存在隐患
                view.RowFilter = string.Empty;
                listView1.DataContext = view;
                listView2.DataContext = view;
                //goodsTableAdapter.Fill(InforDs.Goods);
                //purchaseTableAdapter.Fill(InforDs.Purchase);
                //listView1.DataContext = InforDs.Tables["Goods"];
                //listView2.DataContext = InforDs.Tables["Goods"];
                listView1.SelectedIndex = 0;
                return;
            }
            if (comboBox1.Text == "商品号")
            {
                filterstring = "GoodsNum" + comboBox2.Text + " " + textBox1.Text + " ";
            }
            else if (comboBox1.Text == "保质期/月")
            {
                filterstring = "StoreMonth" + comboBox2.Text + " " + textBox1.Text + " ";
            }
            else if (comboBox1.Text == "价格￥")
            {
                filterstring = "GoodsPrice" + comboBox2.Text + " " + textBox1.Text + " ";
            }
            else if (comboBox1.Text == "商品名")
            {
                if (comboBox2.Text == "=")
                {
                    filterstring = "GoodsName" + " " + comboBox2.Text + " " + "'" + textBox1.Text + "'";
                }
                else
                {
                    filterstring = "GoodsName" + " " + comboBox2.Text + " " + " '" + textBox1.Text + "'";//在filter里面%和*都可做通配符N都不需要
                }
            }
            else if (comboBox1.Text == "生产日期")
            {
                filterstring = "ProduceDate" + " " + comboBox2.Text + " " + "#" + textBox1.Text + "#";//日期两边要加上#
            }
            else//本来代表性别  没啥用了
            {
                filterstring = "GoodsSex " + comboBox2.Text + " N'" + textBox1.Text + "'";
            }
            try
            {
                view.RowFilter = filterstring;
            }
            catch (Exception)
            {
                MessageBox.Show("格式输入不正确，如日期必须输入完整（“2022/1/1”）");
                return;
            }
            listView1.DataContext = view;
            listView2.DataContext = view;
            listView1.SelectedIndex = 0;
            ////////////////////////////////////////////////////补充设置外键
            //InforDs.EnforceConstraints = true;
            ////////////////////////////////////////////////////
        }
        public void Order(object sender, RoutedEventArgs e)
        {
            //view.Table = InforDs.Goods;
            GridViewColumnHeader gridViewColumnHeader = (GridViewColumnHeader)sender;
            string s = "";
            switch (gridViewColumnHeader.Content.ToString())
            {
                case "商品号":
                    s = "GoodsNum";
                    break;
                case "商品名":
                    s = "GoodsName";
                    break;
                case "价格￥":
                    s = "GoodsPrice";
                    break;
                case "生产日期":
                    s = "ProduceDate";
                    break;
                case "保质期/月":
                    s = "StoreMonth";
                    break;
                default: break;
            }
            if (ASC_bool == false)//即从没有执行过升序
            {
                view.Sort = s + " " + "ASC";
                ASC_bool = true;
            }
            else
            {
                view.Sort = s + " " + "DESC";
                ASC_bool = false;
            }
            listView1.ItemsSource = view;
        }
        //强调利用对象的compute函数
        public void MenuItem_Click(object sender, RoutedEventArgs e)//真正的汇总函数
        {
            MenuItem menuItem = (MenuItem)sender;

            DataTable dt = InforDs.Goods.DefaultView.ToTable();//为了只对显示在listview里的数据进行汇总
            switch (menuItem.Header)
            {
                case "求记录数":
                    label1.Content = "记录数 " + dt.Rows.Count.ToString();
                    break;
                case "求最大":
                    label1.Content = "价格最大值 " +dt.Compute(" Max(GoodsPrice) ", "true").ToString();
                    break;
                case "求最小":
                    label1.Content = "价格最小值 " + dt.Compute(" Min(GoodsPrice) ", "true").ToString();
                    break;
                case "求和":
                    label1.Content = "价格求和 " + dt.Compute(" Sum(GoodsPrice) ", "true").ToString();
                    break;
                case "求平均":
                    //label1.Content = "平均价格 " + dt.Compute(" Avg(GoodsPrice)", "true").ToString();//这个返回的整数显得不太精确
                    double a = dt.Rows.Count;
                    double b = Convert.ToDouble(dt.Compute(" Sum(GoodsPrice) ", "true"));
                    label1.Content = "平均价格 " + Math.Round((b / a), 2).ToString();
                    break;
                default: break;
            }
        }
    }//class1
    public class MyData : ObservableCollection<string>
    {
        public MyData()
        {
            InformationDataSetTableAdapters.GoodsTableAdapter goodsTableAdapter = new InformationDataSetTableAdapters.GoodsTableAdapter();
            InformationDataSet informationDataSet = new InformationDataSet();
            goodsTableAdapter.Fill(informationDataSet.Goods);
            DataView dataView = new DataView(informationDataSet.Goods);
            DataTable table = dataView.ToTable(true, "GoodsName");//现在是为了好添加，但是这样得把原来的添加修改的设计得推翻。设计一个新的添加窗口这样固然是很方便。
            //我希望看到革命性的变化，否则就不需要这么忙！！！！！~！
            for (int i = 0; i < table.Rows.Count; i++)
            {
                Add(table.Rows[i]["GoodsName"].ToString());
            }
        }
    }//class2
}
